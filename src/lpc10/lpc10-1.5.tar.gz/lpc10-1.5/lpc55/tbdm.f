***********************************************************************
*
*	TBDM Version 49
*
* $Log: tbdm.f,v $
* Revision 1.3  1996/03/18  22:14:00  jaf
* Just added a few comments about which array indices of the arguments
* are used, and mentioning that this subroutine has no local state.
*
* Revision 1.2  1996/03/13  14:48:37  jaf
* Comments added explaining that none of the local variables of this
* subroutine need to be saved from one invocation to the next.
*
* Revision 1.1  1996/02/07 14:49:54  jaf
* Initial revision
*
*
**********************************************************************
*
* TURBO DIFMAG: Compute High Resolution Average Magnitude Difference Function
* 
* Note: There are several constants in here that appear to depend on a
* particular TAU table.  That's not a problem for the LPC10 coder, but
* watch out if you change the contents of TAU in the subroutine ANALYS.
*
* Input:
*  SPEECH - Low pass filtered speech
*           Indices 1 through MAX+LPITA-1 are read, where:
*           MAX = (TAU(LTAU)-TAU(1))/2+1
*           (If TAU(1) .LT. 39, then larger indices could be read
*           by the last call to DIFMAG below.)
*  LPITA  - Length of speech buffer
*  TAU    - Table of lags, sorted in increasing order.
*           Indices 1 through LTAU read.
*  LTAU   - Number of lag values to compute
* Output:
*  AMDF   - Average Magnitude Difference for each lag in TAU
*           Indices 1 through LTAU written, and several might then be read.
*  MINPTR - Index of minimum AMDF value
*  MAXPTR - Index of maximum AMDF value within +/- 1/2 octave of min
*  MINTAU - Lag corresponding to minimum AMDF value
*
* This subroutine has no local state.
*

	SUBROUTINE TBDM( SPEECH, LPITA, TAU, LTAU, AMDF,
     1                  MINPTR, MAXPTR, MINTAU )

*	Arguments

	INTEGER LPITA, LTAU, MINPTR, MAXPTR, MINTAU
	INTEGER TAU(LTAU)
	REAL SPEECH(312), AMDF(LTAU)
*	REAL SPEECH(LPITA+TAU(LTAU)), AMDF(LTAU)
*   Stupid TOAST doesn't understand expressions

*       Local variables that need not be saved

	INTEGER I, PTR, MINAMD, TAU2(6), LTAU2, MINP2, MAXP2
	REAL AMDF2(6)

*       Local state

*       None

*   Compute full AMDF using log spaced lags, find coarse minimum

	CALL DIFMAG( SPEECH, LPITA, TAU, LTAU, TAU(LTAU),
     1    AMDF, MINPTR, MAXPTR )
	MINTAU = TAU(MINPTR)
	MINAMD = AMDF(MINPTR)

*   Build table containing all lags within +/- 3 of the AMDF minimum
*    excluding all that have already been computed

	LTAU2 = 0
	PTR = MINPTR - 2
	DO I = MAX(MINTAU-3,41), MIN(MINTAU+3,TAU(LTAU)-1)
	   DO WHILE( TAU(PTR).LT.I )
	      PTR = PTR + 1
	   END DO
	   IF( TAU(PTR).NE.I) THEN
	      LTAU2 = LTAU2 + 1
	      TAU2(LTAU2) = I
	   END IF
	END DO

*   Compute AMDF of the new lags, if there are any, and choose one
*    if it is better than the coarse minimum

	IF( LTAU2.GT.0 ) THEN
	   CALL DIFMAG( SPEECH, LPITA, TAU2, LTAU2, TAU(LTAU),
     1       AMDF2, MINP2, MAXP2 )
	   IF( AMDF2(MINP2).LT.MINAMD ) THEN
	      MINTAU = TAU2(MINP2)
	      MINAMD = AMDF2(MINP2)
	   END IF
	END IF

*   Check one octave up, if there are any lags not yet computed

	IF( MINTAU.GE.80 ) THEN
	   I = MINTAU/2
	   IF( AND(I,1).EQ.0 ) THEN
	      LTAU2 = 2
	      TAU2(1) = I-1
	      TAU2(2) = I+1
	   ELSE
	      LTAU2 = 1
	      TAU2(1) = I
	   END IF
	   CALL DIFMAG( SPEECH, LPITA, TAU2, LTAU2, TAU(LTAU),
     1       AMDF2, MINP2, MAXP2 )
	   IF( AMDF2(MINP2).LT.MINAMD ) THEN
	      MINTAU = TAU2(MINP2)
	      MINAMD = AMDF2(MINP2)
	      MINPTR = MINPTR - 20
	   END IF
	END IF

*   Force minimum of the AMDF array to the high resolution minimum

	AMDF(MINPTR) = MINAMD

*   Find maximum of AMDF within 1/2 octave of minimum

	MAXPTR = MAX(MINPTR-5,1)
	DO I = MAXPTR+1, MIN(MINPTR+5,LTAU)
	   IF( AMDF(I).GT.AMDF(MAXPTR) ) MAXPTR = I
	END DO

	RETURN
	END
